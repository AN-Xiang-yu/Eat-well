<template>
    <footer class="flex jc-center background-gris w100 blanc">
        <div class="flex jc-around a-center w100">
            <!-- contact -->
            <div class="flex jc-around mtb-inter-inner footer-infobloc">
                <div>
                    <p>
                        <span class="glyphicon glyphicon-earphone" aria-hidden="true"></span>
                        <span>&emsp;&emsp;</span>
                        <a href="tel:+33188289000">+33 6 66 66 66 66</a>
                    </p>
                </div>
                <div>
                    <p>
                        <span class="glyphicon glyphicon-envelope" aria-hidden="true"></span>
                        <span>&emsp;&emsp;</span>
                        <a href="Mailto:contact@eatwell.fr?Subject=Bonjour&Body=Bonjour">contact@eatwell.fr</a>
                    </p>
                </div>
            </div>
            <!-- Copyright -->
            <div class="flex-100 center mtb-inter-inner">
                <p>Copyright©2013-2021 EW - All Rights Reserved. </p>
                <p>eatwell.fr</p>
            </div>
        </div>
    </footer>
</template>

<script>
module.exports ={
    name: 'MonFooter', 
        data () {
        return {

        }
    },
    methods: {

    }
}
</script>