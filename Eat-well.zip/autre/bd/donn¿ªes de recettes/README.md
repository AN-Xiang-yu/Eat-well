# text-mining
Classification supervisée des recettes sur Marmiton
Predicton du type de plat, en fonction du texte de la recette ( données webscrapées sur le site de Marmiton ) .
